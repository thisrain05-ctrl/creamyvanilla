# Creamy Vanilla (NeoForge 1.21.1)

By **Celestial878**. Several small additions in one mod.

## Config
`config/creamyvanilla-common.toml` -> `[sack]`: `slots`, `sack_penalty`, `sack_increment`.

## Tags
- `creamyvanilla:sacks` (block and item), `creamyvanilla:overencumbering` (item)
- Harvesting: `creamyvanilla:extra_crops`, `creamyvanilla:blacklist`, `creamyvanilla:separate_stacked` (block tags)

## Commands
    /give @s minecraft:diamond_hoe[enchantments={"creamyvanilla:harvesting":1}]
    /give @s minecraft:diamond_sword[attribute_modifiers={modifiers:[{type:"creamyvanilla:looting",id:"mypack:looting",amount:2,operation:"add_value",slot:"mainhand"}]}]

## Credits
See [CREDITS.md](CREDITS.md). The sack is a fork of the sack from
[Supplementaries](https://www.curseforge.com/minecraft/mc-mods/supplementaries) (code and art), and the harvesting
action uses code from [Harvest with Ease](https://modrinth.com/mod/harvest-with-ease).

## Build
    ./gradlew build
The jar is written to `build/libs/creamyvanilla-1.0.0.jar`. Requires Java 21.
